
/**
 * Write a description of class Jar here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Jar
{
    private int position;
    private Stone stone;
    /**
     * Constructor for objects of class Jar
     */
    public Jar()
    {
        // initialise instance variables
        position = 0;
        stone = null;
    }
}
