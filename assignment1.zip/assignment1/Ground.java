/**
 * Write a description of class Ground here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Ground
{
    /**
     * Constructor for objects of class Ground
     */
       private Player player;
       private Jar jar1;
       private Jar jar2;
       private Jar jar3;
    public Ground()
    {
       
    }
}
