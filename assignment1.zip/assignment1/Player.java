
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.Scanner;
public class Player
{
    // instance variables - replace the example below with your own
    private String name;
    private int position;
    private Jar jar;

    /**
     * Constructor for objects of class Player
     */
    public Player()
    {
        position = 0;
        jar = new Jar();
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter player's name: ");
        name = Global.keyboard.nextLine();
    }
}
